#include "Box_depricated.h"

BoxParametres::BoxParametres(float pos_px_x_, float pos_px_y_, float dencity_, float friction_, float restitution_, game::BodyType body_type)
{
	initial_pos.Set(game::PosType::Pixel, pos_px_x_, pos_px_y_);
	dencity = dencity_;
	friction = friction_;
	restitution = restitution_;
	type = body_type;
}

Box_d::Box_d(b2World & world, std::string name, AnimationPack const & animation, BoxParametres const & parameteres) :_animation(animation)
{
	b2BodyDef body_def;
	switch (parameteres.type)
	{
	case game::BodyType::Static :
		body_def.type = b2_staticBody;
		break;
	case game::BodyType::Dynamic :
		body_def.type = b2_dynamicBody;
		break;
	default:
		body_def.type = b2_kinematicBody;
		break;
	}
	b2PolygonShape shape;
	shape.SetAsBox(animation.GetFrameWidth(), animation.GetFrameHeight());
	b2FixtureDef fixture_def;
	fixture_def.density = parameteres.dencity;
	fixture_def.friction = parameteres.friction;
	fixture_def.restitution = parameteres.restitution;
	fixture_def.shape = &shape;
	body_def.position.Set(animation.GetFrameWidth(), animation.GetFrameHeight());
	_body = world.CreateBody(&body_def);
	_body->CreateFixture(&fixture_def);
	_body->SetUserData(new std::string (name));
}

void Box_d::update(game::Window & window)
{
	_animation.draw(window, game::Position(), 0);
}


void Box_d::Destroy()
{
	_body->GetWorld()->DestroyBody(_body);
}


Box_d::~Box_d()
{
	Destroy();
}
